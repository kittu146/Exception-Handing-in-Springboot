package com.example.User.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.User.Entity.User;
import com.example.User.Exception.InvalidUserException;
import com.example.User.Exception.UserNotFoundException;
import com.example.User.Repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Create or Update a User
    public User saveUser(User user) {
        if (user.getEmail() == null || user.getEmail().isEmpty()) {
            throw new InvalidUserException("Email is required");
        }
        return userRepository.save(user);
    }

    // Get a User by ID
    public User getUserById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new UserNotFoundException("User not found with ID: " + id));
    }

    // Get a User by email
    public User getUserByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + email));
    }

    // Update a User
    public User updateUser(Long id, User user) {
        User existingUser = getUserById(id);
        existingUser.setName(user.getName());
        existingUser.setEmail(user.getEmail());
        return userRepository.save(existingUser);
    }

    // Delete a User
    public void deleteUser(Long id) {
        User user = getUserById(id);
        userRepository.delete(user);
    }

    // Get all Users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}
